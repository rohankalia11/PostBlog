package com.example.mineproject;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class OnStart extends AppCompatActivity {


    Button loginbtn,signupbtn;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(R.layout.activity_on_start);

        loginbtn = findViewById(R.id.lbtn);
        signupbtn=findViewById(R.id.sbtn);
        mAuth=FirebaseAuth.getInstance();


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(OnStart.this,LoginActivity.class);
                startActivity(intent);
            }
        });


        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(OnStart.this,SignupActivity.class);
                startActivity(intent);
            }
        });



    }



    @Override
    protected void onStart() {
        super.onStart();

        //to check if user currently login or not

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser !=null)
        {
            sendToMain();

        }

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    private void sendToMain() {


        Intent mainIntent = new Intent(OnStart.this,MainActivity.class);
        startActivity(mainIntent);
        finish();
    }
}
